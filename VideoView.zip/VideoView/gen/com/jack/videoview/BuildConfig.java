/** Automatically generated file. DO NOT MODIFY */
package com.jack.videoview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}