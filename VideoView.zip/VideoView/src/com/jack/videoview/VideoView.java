package com.jack.videoview;

import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class VideoView extends ActionBarActivity implements OnPreparedListener,
		OnErrorListener {
	private MyVideoView video1;
	private Intent intent;
	private Intent intents;
	private TextView text;
	private int mPlayingPos = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);// �����ر�����
		// requestWindowFeature(Window.FEATURE_ACTION_BAR);//
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);// ��ȫ��
		setContentView(R.layout.activity_video_view);
		text = (TextView) findViewById(R.id.text1);
		video1 = (MyVideoView) findViewById(R.id.video1);
		intents = getIntent();
		// video1.getHolder().setFixedSize(300, 500);
		String uri = "android.resource://" + getPackageName() + "/"
				+ R.raw.xuanchuan;
		// String uri="http://clips.vorwaerts-gmbh.de/big_buck_bunny.mp4";
		video1.setVideoURI(Uri.parse(uri));
		// video1.setMediaController(new android.widget.MediaController(this));

		video1.requestFocus();
		video1.setOnPreparedListener(this);
		video1.setOnErrorListener(this);
		video1.start();
		video1.setOnCompletionListener(new OnCompletionListener() {

			@Override
			public void onCompletion(MediaPlayer mp) {
				// TODO Auto-generated method stub
				if (intents.getIntExtra("donghua", 0) == 1) {
					intent = new Intent(VideoView.this, ShowActivity.class);
					intent.putExtra("x1", "x1");
				} else {
					intent = new Intent(VideoView.this, MainActivity.class);
				}
				startActivity(intent);
				finish();
			}
		});
		text.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub

				if (intents.getIntExtra("donghua", 0) == 1) {
					intent = new Intent(VideoView.this, ShowActivity.class);
					intent.putExtra("x1", "x1");
				} else {
					intent = new Intent(VideoView.this, MainActivity.class);
				}
				startActivity(intent);
				finish();
			}
		});
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		video1.suspend();
		super.onDestroy();
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		if (video1 != null && video1.isPlaying()) {
			mPlayingPos = video1.getCurrentPosition(); // �Ȼ�ȡ��stopPlay(),ԭ���Լ���Դ��
			video1.stopPlayback();
		}
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		if (mPlayingPos > 0) {
			video1.start();
			video1.seekTo(mPlayingPos);
			mPlayingPos = 0;
		}

	}

	@Override
	public boolean onError(MediaPlayer mp, int what, int extra) {
		// TODO Auto-generated method stub
		if (intents.getIntExtra("donghua", 0) == 1) {
			intent = new Intent(VideoView.this, ShowActivity.class);
			intent.putExtra("x1", "x1");
		} else {
			intent = new Intent(VideoView.this, MainActivity.class);
		}
		startActivity(intent);
		finish();
		return false;
	}

	@Override
	public void onPrepared(MediaPlayer mp) {
		// TODO Auto-generated method stub

	}

}
